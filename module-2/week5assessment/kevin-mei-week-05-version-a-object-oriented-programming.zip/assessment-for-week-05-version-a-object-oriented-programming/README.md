# Assesssment for Week 5 Unit Test Problems

## Usage

1. Clone the starter from github here [object-oriented-programming]
2. Rename the folder to `firstname-lastname-week-5-object-oriented-programming`.
For example, if your name is "Jane Doe", then name your folder
`jane-doe-week-5-object-oriented-programming`
3. `cd` into the folder and `npm install` to install dependencies
4. Run the tests by typing `npm test`.
5. Your objective is to implement the code in each of the following JavaScript
   files so that when you run Mocha, all 35 tests pass.
   * **class-inheritance-a.js**
   * **class-instance-method-a.js**
   * **class-instances-a.js**
   * **nodejs-module-import-export-a.js**

Your report will look like this when you are done.

```
The Vehicle class
   ✓ should not be null
   ✓ should be a class
   should include a constructor method that initializes
   ✓ the `weight` property from the provided argument value
   ✓ the `capacity` property from the provided argument value

The Airplane class
   ✓ should not be null
   ✓ should be a class
   should include a constructor method that initializes
   ✓ the `numberOfEngines` property from the provided argument value
   ✓ the `wingspan` property from the provided argument value
   ✓ the `weight` property from the provided argument value
   ✓ the `capacity` property from the provided argument value
   should create objects that are
   ✓ instances of the Airplane class
   ✓ instances of the Vehicle class

The Airplane class
   ✓ should not be null
   ✓ should be a class
   should include a constructor method that initializes
   ✓ the `numberOfEngines` property from the provided argument value
   ✓ the `wingspan` property from the provided argument value
   should include
   ✓ an instance method named `getConfiguration()`
   that
      ✓ returns the expected value

The Passenger class
   ✓ should not be null
   ✓ should be a class
   should include a constructor method that initializes
   ✓ the `firstName` property from the provided argument value
   ✓ the `lastName` property from the provided argument value

The sallySmith instance
   ✓ should not be null
   ✓ should be an instance of the Passenger class
   ✓ should have a firstName property initialized to value 'Sally'
   ✓ should have a lastName property initialized to value 'Smith'

The johnJones instance
   ✓ should not be null
   ✓ should be an instance of the Passenger class
   ✓ should have a firstName property initialized to value 'John'
   ✓ should have a lastName property initialized to value 'Jones'

The module
   ✓ exports a non-null, non-empty object
   that
   ✓ defines a Employee property that references the Employee class
   ✓ defines a Contractor property that references the Contractor class

The Employee class
   ✓ inherits from the Worker class

The Contractor class
   ✓ inherits from the Worker class


35 passing (26ms)
```

## Submission

When you are ready to submit:

1. Delete the `node_modules` directory
2. Zip up your folder
3. Upload it

[object-oriented-programming]: https://github.com/appacademy/assessment-for-week-05-version-a-object-oriented-programming