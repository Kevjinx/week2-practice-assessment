This file is used to manually trigger the build process.  It is here to provide
a defined place to commit a trivial change.  It may be ignored by students.

To use, simply add the date and time below and commit to branch->staging->master
as normal.

2/1/20 9:40 am
2/18/20 9:33 am