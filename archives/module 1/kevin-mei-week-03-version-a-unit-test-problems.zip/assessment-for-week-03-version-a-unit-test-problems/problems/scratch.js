const str1 = 'thaz'
const str2 = 'that'

console.log(str1 > str2)


// const arr = [1, 2, 0]
// let min = 11;
// let ree = arr.reduce((acc, ele) => {
//   if (min > ele) {
//     return acc = ele
//   }
// })

// console.log(ree);