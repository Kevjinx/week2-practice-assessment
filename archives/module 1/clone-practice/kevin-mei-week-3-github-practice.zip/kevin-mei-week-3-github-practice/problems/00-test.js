/*

Write a function, `helloWorld`, that will return the string of 'Hello World!'

*/


// your code here

const helloWorld = () => 'Hello World!'


/**************DO NOT MODIFY ANYTHING UNDER THIS  LINE*****************/
try {
  module.exports = helloWorld;
} catch (e) {
  module.exports = null;
}
